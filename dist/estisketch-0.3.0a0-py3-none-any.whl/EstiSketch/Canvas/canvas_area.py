from ..components import Layer
from ..components import Layer, Level
from ..roof_components import Roof, RoofEdge
from .events_helpers import EventsHelpersMixin
from .utils import UtilsMixin
from .events_edit import EditEventsMixin
from .events_tools import CanvasToolsMixin
from .events_room import CanvasRoomMixin
from .events_wall import CanvasWallMixin
from .events_roof import CanvasRoofEventsMixin
from .events_selection import CanvasSelectionMixin
from .canvas_tool import CanvasToolMixin
from .canvas_geometry import CanvasGeometryMixin
from .canvas_state import CanvasStateMixin
from .canvas_events import CanvasEventsMixin
from .canvas_draw import CanvasDrawMixin
from ..snapping_manager import SnappingManager
from ..components import Wall, Room, Text, Dimension, Layer, Level
from ..measurement_utils import MeasurementConverter
from gi.repository import Gtk, Gdk, GObject
import gi
gi.require_version('Gtk', '4.0')


class CanvasArea(Gtk.DrawingArea,
                 CanvasDrawMixin,
                 CanvasEventsMixin,
                 CanvasStateMixin,
                 CanvasGeometryMixin,
                 CanvasToolMixin,
                 CanvasSelectionMixin,
                 CanvasWallMixin,
                 CanvasRoofEventsMixin,
                 CanvasRoomMixin,
                 CanvasToolsMixin,
                 EditEventsMixin,
                 UtilsMixin,
                 EventsHelpersMixin):

    __gtype_name__ = 'CanvasArea'
    __gsignals__ = {
        # when selection changes, send the new list of selected items
        'selection-changed': (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        # when tool hint needs updating
        'status-update': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        # when configuration changes
        'config-changed': (GObject.SignalFlags.RUN_FIRST, None, ()),
        # when canvas content changes (objects added/removed/properties changed)
        'content-changed': (GObject.SignalFlags.RUN_FIRST, None, ()),
    }

    def __init__(self, config_constants):
        super().__init__()
        self.config = config_constants
        self.converter = MeasurementConverter()

        self.set_focusable(True)
        self.grab_focus()
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.set_draw_func(self.on_draw)

        # Zoom and pan
        self.zoom = self.config.DEFAULT_ZOOM_LEVEL
        self.ruler_offset = 80
        self.offset_x = self.ruler_offset
        self.offset_y = self.ruler_offset

        # Layers system - max 24 layers
        self.MAX_LAYERS = 24
        # Create default layer using generate_identifier
        default_layer_id = self.generate_identifier("layer", [])

        # Level system
        self.levels = [Level(id="level-1", name="Level 1", elevation=0.0)]
        self.active_level_id = "level-1"
        self.show_all_levels = False

        self.layers = [Layer(
            id=default_layer_id,
            name="Layer 0",
            visible=True,
            locked=False,
            opacity=1.0,
            level_id="level-1"  # Default layer assigned to default level
        )]
        self.active_layer_id = default_layer_id

        # Wall drawing state
        self.walls = []
        self.current_wall = None
        self.drawing_wall = False
        self.wall_sets = []

        # Curved wall state (for 3-point arc walls)
        self.wall_curve_mode = False  # True when waiting for arc bulge point (3rd click)
        self.wall_curve_point = None  # The arc bulge point for preview

        self.auto_dimension_mode = False
        self.last_wall_angle = None

        # Wall editing state
        self.editing_wall = None     # The wall being edited
        self.editing_handle = None   # "start" or "end"
        self.handle_radius = 15      # device pixels for hit detection

        # Polyline drawing state
        # current segments (list of Polyline)
        self.polylines = []
        self.current_polyline_start = None  # last click point
        self.current_polyline_preview = None   # live endpoint while moving
        self.drawing_polyline = False      # are we in the middle of drawing?
        self.polyline_sets = []            # list of finished polyline lists

        # Room drawing state
        self.rooms = []                # Finalized Room objects
        self.current_room_points = []  # Manual room drawing points
        self.current_room_preview = None  # Live preview point (snapped)

        # List of door placements; each item is a tuple: (wall, door,
        # position_ratio)
        self.doors = []
        # List of window placements; each item is a tuple: (wall, window,
        # position_ratio)
        self.windows = []
        self.texts = []  # List of Text objects

        # Dimension drawing state
        self.dimensions = []  # List of finalized Dimension objects
        self.drawing_dimension = False  # Flag for dimension mode
        self.dimension_start = None  # First click point (x, y)
        self.dimension_end = None  # Second click point (x, y)
        self.dimension_offset_preview = None  # Mouse position for offset preview

        # Alignment snapping (used for walls and rooms)
        self.alignment_candidate = None
        self.raw_current_end = None

        self.snap_type = "none"
        self.tool_mode = None  # "draw_walls" or "draw_rooms"

        # ID stack
        self.existing_ids = []

        # Undo/Redo stacks
        self.undo_stack = []
        self.redo_stack = []

        # Selection variables
        self.selected_items = []
        self.box_selecting = False
        self.box_select_start = (0, 0)
        self.box_select_end = (0, 0)

        # Clipboard for copy/paste operations
        self.clipboard = []

        # Expose Wall and Room for mixins
        self.Wall = Wall
        self.Room = Room
        self.Text = Text
        self.Dimension = Dimension
        from ..components import Circle, Arc
        self.Circle = Circle
        self.Arc = Arc

        # Circle drawing state
        self.circles = []
        self.drawing_circle = False
        self.circle_center = None
        self.circle_radius_preview = None

        # Arc drawing state
        self.arcs = []
        self.drawing_arc = False
        self.arc_start = None
        self.arc_end = None
        self.arc_preview_point = None

        # Roof state
        self.roofs = []  # List of Roof objects
        self.Roof = Roof
        self.RoofEdge = RoofEdge

        # Initialize snapping manager
        self.snap_manager = SnappingManager(
            snap_enabled=self.config.SNAP_ENABLED,
            snap_threshold=self.config.SNAP_THRESHOLD,
            config=self.config,
            zoom=self.zoom
        )

        # Set up input controllers (delegated to the events mixin)
        scroll_controller = Gtk.EventControllerScroll.new(
            Gtk.EventControllerScrollFlags.NONE)
        scroll_controller.connect("scroll", self.on_scroll)
        self.add_controller(scroll_controller)

        click_gesture = Gtk.GestureClick.new()
        click_gesture.connect("pressed", self.on_click_pressed)
        click_gesture.connect("released", self.on_click)
        self.add_controller(click_gesture)

        drag_gesture = Gtk.GestureDrag.new()
        drag_gesture.connect("drag-begin", self.on_drag_begin)
        drag_gesture.connect("drag-update", self.on_drag_update)
        drag_gesture.connect("drag-end", self.on_drag_end)
        self.add_controller(drag_gesture)

        motion_controller = Gtk.EventControllerMotion.new()
        motion_controller.connect("motion", self.on_motion)
        self.add_controller(motion_controller)

        pinch_gesture = Gtk.GestureZoom.new()
        pinch_gesture.connect("scale-changed", self.on_zoom_changed)
        self.add_controller(pinch_gesture)

        # Create a gesture click dedicated to right-click (secondary button)
        right_click_gesture = Gtk.GestureClick.new()
        # Listen for right-click events.
        right_click_gesture.set_button(Gdk.BUTTON_SECONDARY)
        right_click_gesture.connect("pressed", self.on_right_click)
        self.add_controller(right_click_gesture)

    def adjust_zoom(self, factor, center_x, center_y):
        # Calculate the new zoom level.
        new_zoom = self.zoom * factor
        # Adjust offsets so that the point at (center_x, center_y) stays fixed.
        self.offset_x = center_x - factor * (center_x - self.offset_x)
        self.offset_y = center_y - factor * (center_y - self.offset_y)
        self.zoom = new_zoom
        self.queue_draw()

    def reset_zoom(self):
        self.zoom = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.queue_draw()

    def update_hint(self, message):
        """Emit status-update signal with message."""
        self.emit('status-update', message)

    def clear(self):
        """Clear all drawing elements from the canvas."""
        self.walls = []
        self.wall_sets = []
        self.rooms = []
        self.doors = []
        self.windows = []
        self.polylines = []
        self.polyline_sets = []
        self.dimensions = []
        self.texts = []
        self.circles = []
        self.arcs = []
        self.roofs = []

        # Clear selection
        self.selected_items = []

        # Reset drawing states
        self.current_wall = None
        self.drawing_wall = False
        self.current_room_points = []
        self.current_room_preview = None
        self.current_polyline_start = None
        self.current_polyline_preview = None
        self.drawing_polyline = False
        self.drawing_dimension = False
        self.dimension_start = None
        self.dimension_end = None
        self.dimension_offset_preview = None
        self.drawing_circle = False
        self.circle_center = None
        self.circle_radius_preview = None
        self.drawing_arc = False
        self.arc_start = None
        self.arc_end = None
        self.arc_preview_point = None

        # Clear undo/redo stacks
        self.undo_stack = []
        self.redo_stack = []

        # Clear existing IDs (if applicable, depends on how IDs are managed)
        self.existing_ids = []

        # Load levels and layers from config (assuming this method re-initializes them)
        # If _initialize_levels_and_layers() is meant to be called here, it should be defined.
        # For now, assuming it's a placeholder or will be added elsewhere.
        # self._initialize_levels_and_layers()

        self.queue_draw()
        self.emit('selection-changed', self.selected_items)


    # ─────────────────────────────────────────────────────────────────────────
    # Layer Management Methods
    # ─────────────────────────────────────────────────────────────────────────

    def add_layer(self, name: str = None, level_id: str = None) -> str:
        """Add a new layer and return its ID. Returns None if max layers reached."""
        if len(self.layers) >= self.MAX_LAYERS:
            print(f"Cannot add more than {self.MAX_LAYERS} layers")
            return None

        existing_ids = [layer.id for layer in self.layers]
        new_layer_id = self.generate_identifier("layer", existing_ids)
        layer_num = len(self.layers)
        layer_name = name if name else f"Layer {layer_num}"

        # Default to active level if not specified
        if level_id is None:
            # If show all levels is on, maybe we should ask user?
            # For now default to active level
            level_id = self.active_level_id

        new_layer = Layer(
            id=new_layer_id,
            name=layer_name,
            visible=True,
            locked=False,
            opacity=1.0,
            level_id=level_id
        )
        self.layers.append(new_layer)
        return new_layer_id

    def remove_layer(self, layer_id: str) -> bool:
        """Remove a layer by ID. Cannot remove last layer. Returns True if removed."""
        if len(self.layers) <= 1:
            print("Cannot remove the last layer")
            return False

        for i, layer in enumerate(self.layers):
            if layer.id == layer_id:
                self.layers.pop(i)
                # If active layer was removed, switch to first layer
                if self.active_layer_id == layer_id:
                    self.active_layer_id = self.layers[0].id
                return True
        return False

    def get_layer_by_id(self, layer_id: str):
        """Get a Layer object by its ID."""
        for layer in self.layers:
            if layer.id == layer_id:
                return layer
        return None

    def set_active_layer(self, layer_id: str) -> bool:
        """Set the active layer by ID. Returns True if successful."""
        layer = self.get_layer_by_id(layer_id)
        if layer:
            self.active_layer_id = layer_id
            self.queue_draw()
            return True
        return False

    def get_visible_layer_ids(self) -> set:
        """Get set of IDs for all visible layers."""
        return {layer.id for layer in self.layers if layer.visible}

    def get_locked_layer_ids(self) -> set:
        """Get set of IDs for all locked layers."""
        return {layer.id for layer in self.layers if layer.locked}

    def is_object_on_visible_layer(self, obj) -> bool:
        """
        Check if an object is on a visible layer.
        Taking into account:
        1. Layer visibility flag
        2. Active Level (unless show_all_levels or global layer)
        """
        layer_id = getattr(obj, 'layer_id', '')
        if not layer_id:
            return True

        layer = self.get_layer_by_id(layer_id)
        if not layer:
            return True  # Legacy/Fallback

        if not layer.visible:
            return False

        # Check object-level visibility
        if hasattr(obj, 'visible') and not obj.visible:
            return False

        # Check level filtering
        if self.show_all_levels:
            return True

        # Global layers (empty level_id) are always visible
        if not layer.level_id:
            return True

        # Otherwise must match active level
        return layer.level_id == self.active_level_id

    def is_object_on_locked_layer(self, obj) -> bool:
        """Check if an object is on a locked layer or is individually locked."""
        # Check object-level lock
        if hasattr(obj, 'locked') and obj.locked:
            return True

        layer_id = getattr(obj, 'layer_id', '')
        if not layer_id:  # Empty layer_id means not locked by layer
            return False
        return layer_id in self.get_locked_layer_ids()

    def get_object_opacity(self, obj) -> float:
        """Get the opacity of an object based on its layer."""
        layer_id = getattr(obj, 'layer_id', '')
        if not layer_id:
            return 1.0

        layer = self.get_layer_by_id(layer_id)
        if layer:
            # Focus Mode Logic
            if getattr(self.config, "LAYER_FOCUS_MODE", False):
                # If active layer is not found (shouldn't happen), default to 1.0
                active_layer = self.get_layer_by_id(self.active_layer_id)
                if not active_layer:
                    return 1.0

                # Determine if object's layer is active or above/below
                # Layers are ordered bottom to top in self.layers
                try:
                    obj_layer_index = self.layers.index(layer)
                    active_layer_index = self.layers.index(active_layer)

                    if obj_layer_index < active_layer_index:
                        return 0.25  # Below active layer -> dimmed
                    else:
                        return 1.0   # Active or above -> full opacity
                except ValueError:
                    return 1.0 # Fallback if layer not in list

            # Normal Mode: use layer opacity
            return layer.opacity
        return 1.0

    def get_objects_by_layer_id(self, layer_id: str):
        """Return a list of (type_name, object) tuples for all objects on the given layer."""
        objects = []
        
        # Walls
        for wall_set in self.wall_sets:
            for wall in wall_set:
                if wall.layer_id == layer_id:
                    objects.append(("wall", wall))
                    
        # Rooms
        for room in self.rooms:
            if room.layer_id == layer_id:
                objects.append(("room", room))
                
        # Doors
        for item in self.doors:
            # item is (wall, door, ratio)
            if item[1].layer_id == layer_id:
                objects.append(("door", item[1]))
                
        # Windows
        for item in self.windows:
            if item[1].layer_id == layer_id:
                objects.append(("window", item[1]))
                
        # Text
        for text in self.texts:
            if text.layer_id == layer_id:
                objects.append(("text", text))
                
        # Dimensions
        for dim in self.dimensions:
            if dim.layer_id == layer_id:
                objects.append(("dimension", dim))
                
        # Polylines
        for poly_set in self.polyline_sets:
            for poly in poly_set:
                if poly.layer_id == layer_id:
                    objects.append(("polyline", poly))

        # Circles
        for circle in self.circles:
            if circle.layer_id == layer_id:
                objects.append(("circle", circle))

        # Arcs
        for arc in self.arcs:
            if arc.layer_id == layer_id:
                objects.append(("arc", arc))
                
        # Roofs
        if hasattr(self, 'roofs'):
            for roof in self.roofs:
                 if getattr(roof, 'layer_id', '') == layer_id:
                    objects.append(("roof", roof))

        return objects

    # ─────────────────────────────────────────────────────────────────────────
    # Level Management Methods
    # ─────────────────────────────────────────────────────────────────────────

    def add_level(self, name: str) -> str:
        """Add a new level and return its ID."""
        existing_ids = [l.id for l in self.levels]
        new_id = self.generate_identifier("level", existing_ids)

        # Calculate default elevation
        elevation = 0.0
        default_height = getattr(self.config, 'DEFAULT_LEVEL_HEIGHT', 96.0)
        
        if self.levels:
            # Use the configured default height as the offset from the previous level
            # satisfying the user's expectation that the setting controls the spacing
            elevation = self.levels[-1].elevation + default_height

        from ..components import Level
        new_level = Level(id=new_id, name=name, elevation=elevation, height=default_height)
        self.levels.append(new_level)
        return new_id

    def remove_level(self, level_id: str) -> bool:
        """Remove a level. Cannot remove the last level."""
        if len(self.levels) <= 1:
            return False

        for i, level in enumerate(self.levels):
            if level.id == level_id:
                self.levels.pop(i)
                # If active level removed, switch to first
                if self.active_level_id == level_id:
                    self.active_level_id = self.levels[0].id
                    # Also switch active layer if it belonged to removed level
                    active_layer = self.get_layer_by_id(self.active_layer_id)
                    if active_layer and active_layer.level_id == level_id:
                        # Find a layer on the new active level or global
                        self._ensure_valid_active_layer()
                return True
        return False

    def set_active_level(self, level_id: str):
        """Set the active level and refresh visibility."""
        # Validate ID
        if not any(l.id == level_id for l in self.levels):
            return

        self.active_level_id = level_id

        # Ensure active layer is valid for this level
        self._ensure_valid_active_layer()

        self.queue_draw()

    def _initialize_levels_and_layers(self):
        """Initializes levels and layers, typically called on clear or load."""
        # This method was referenced in the provided snippet for 'clear',
        # but not defined in the original document.
        # Assuming it would handle setting up default levels and layers.
        # For now, it's an empty placeholder.
        pass

    def _ensure_valid_active_layer(self):
        """Ensure the active layer belongs to the active level or is global."""
        active_layer = self.get_layer_by_id(self.active_layer_id)

        # If active layer is global or on current level, we're good
        if active_layer and (
                not active_layer.level_id or active_layer.level_id == self.active_level_id):
            return

        # Otherwise try to find a layer on this level
        for layer in self.layers:
            if layer.level_id == self.active_level_id:
                self.active_layer_id = layer.id
                return

        # Or a global layer
        for layer in self.layers:
            if not layer.level_id:
                self.active_layer_id = layer.id
                return

        # If all else fails, create a default layer for this level
        from ..components import Layer
        # add_layer will need update or manual handling?
        new_id = self.add_layer(f"Layer 1")
        # Actually add_layer needs to know about current level.
        # For now, let's fix add_layer separately or handle it here?
        # Let's fix add_layer in the next chunk/step, but for now just fallback
        # to 0
        if self.layers:
            self.active_layer_id = self.layers[0].id

    def delete_selected(self):
        """
        Delete the currently selected object(s) from the canvas.
        Supports walls, rooms, polylines, doors, and windows.
        """
        if not self.selected_items:
            return

        room_vertices_to_delete = {}  # room_identifier -> list of indices

        for item in list(self.selected_items):
            item_type = item.get("type") # Get type once for cleaner checks

            # Walls
            if item_type == "wall":
                selected_id = item["object"].identifier
                for wall_set in self.wall_sets:
                    for wall in wall_set:
                        if wall.identifier == selected_id:
                            wall_set.remove(wall)

                    # If wall set is empty remove it
                    if len(wall_set) == 0:
                        self.wall_sets.remove(wall_set)

            # Rooms
            elif item_type == "vertex":
                # item["object"] is (room, index)
                room = item["object"][0]
                index = item["object"][1]
                if room.identifier not in room_vertices_to_delete:
                    room_vertices_to_delete[room.identifier] = []
                room_vertices_to_delete[room.identifier].append(index)

            # Polylines: search and remove from polyline_sets (list of lists)
            elif item_type == "polyline":
                # selection entries may come from click (object only) or
                # box-select (object + identifier)
                selected_obj = item.get("object")
                selected_id = item.get("identifier") or getattr(
                    selected_obj, "identifier", None)
                # iterate over a copy so removals are safe
                for poly_list in list(self.polyline_sets):
                    found_index = None
                    # find the exact segment by identity or by identifier
                    for idx, segment in enumerate(poly_list):
                        if segment is selected_obj or (
                            selected_id is not None and getattr(
                                segment, "identifier", None) == selected_id):
                            found_index = idx
                            break
                    if found_index is not None:
                        del poly_list[found_index]
                    if len(poly_list) == 0:
                        self.polyline_sets.remove(poly_list)
            # Doors
            elif item_type == "door":
                # item["object"] is (wall, door, ratio) tuple
                door_tuple = item["object"]
                if door_tuple in self.doors:
                    self.doors.remove(door_tuple)
            # Windows
            elif item_type == "window":
                # item["object"] is (wall, window, ratio) tuple
                window_tuple = item["object"]
                if window_tuple in self.windows:
                    self.windows.remove(window_tuple)

            # Text
            elif item_type == "text":
                text_obj = item["object"]
                if text_obj in self.texts:
                    self.texts.remove(text_obj)

            # Dimension
            elif item_type == "dimension":
                dim_obj = item["object"]
                if dim_obj in self.dimensions:
                    self.dimensions.remove(dim_obj)

            # Circle
            elif item_type == "circle":
                circle_obj = item["object"]
                if circle_obj in self.circles:
                    self.circles.remove(circle_obj)

            # Arc
            elif item_type == "arc":
                arc_obj = item["object"]
                if arc_obj in self.arcs:
                        self.arcs.remove(arc_obj)
            elif item_type == "roof":
                target_roof = item["object"]
                if hasattr(self, 'delete_roof'): # Prefer specialized delete if available
                    self.delete_roof(target_roof)
                elif target_roof in getattr(self, 'roofs', []): # Fallback to direct list removal
                     self.roofs.remove(target_roof)

        # Process room vertex deletions
        for room_id, indices in room_vertices_to_delete.items():
            # Find the actual room object in self.rooms
            target_room = next(
                (r for r in self.rooms if r.identifier == room_id), None)
            if not target_room:
                continue

            # Sort indices in descending order so earlier indices remain valid
            indices.sort(reverse=True)

            # Delete all requested vertices
            for idx in indices:
                if 0 <= idx < len(target_room.points):
                    del target_room.points[idx]

            # After all deletions, check if room still has enough points
            # Rooms now store only unique vertices (no closing point)
            # Need at least 3 points for a valid polygon
            if len(target_room.points) < 3:
                if target_room in self.rooms:
                    self.rooms.remove(target_room)

        self.selected_items.clear()
        self.queue_draw()
        self.emit('selection-changed', self.selected_items)
        self.emit('content-changed')

    def select_all(self):
        """Select all objects on the canvas"""
        self.selected_items.clear()

        # Select all walls
        for wall_set in self.wall_sets:
            for wall in wall_set:
                if not self.is_object_on_locked_layer(
                        wall) and self.is_object_on_visible_layer(wall):
                    self.selected_items.append(
                        {"type": "wall", "object": wall})

        # Select all room vertices
        for room in self.rooms:
            if not self.is_object_on_locked_layer(
                    room) and self.is_object_on_visible_layer(room):
                for idx in range(len(room.points)):
                    self.selected_items.append(
                        {"type": "vertex", "object": (room, idx)})

        # Select all doors
        for door_item in self.doors:
            # door_item is (wall, door, ratio)
            # check the door object (index 1)
            if not self.is_object_on_locked_layer(
                    door_item[1]) and self.is_object_on_visible_layer(
                    door_item[1]):
                self.selected_items.append(
                    {"type": "door", "object": door_item})

        # Select all windows
        for window_item in self.windows:
            if not self.is_object_on_locked_layer(
                    window_item[1]) and self.is_object_on_visible_layer(
                    window_item[1]):
                self.selected_items.append(
                    {"type": "window", "object": window_item})

        # Select all text objects
        for text in self.texts:
            if not self.is_object_on_locked_layer(
                    text) and self.is_object_on_visible_layer(text):
                self.selected_items.append({"type": "text", "object": text})

        # Select all dimensions
        for dim in self.dimensions:
            if not self.is_object_on_locked_layer(
                    dim) and self.is_object_on_visible_layer(dim):
                self.selected_items.append(
                    {"type": "dimension", "object": dim})

        # Select all polylines
        for polyline_set in self.polyline_sets:
            for polyline in polyline_set:
                if not self.is_object_on_locked_layer(
                        polyline) and self.is_object_on_visible_layer(polyline):
                    self.selected_items.append(
                        {"type": "polyline", "object": polyline})

        # Select all circles
        for circle in self.circles:
            if not self.is_object_on_locked_layer(circle) and self.is_object_on_visible_layer(circle):
                self.selected_items.append({"type": "circle", "object": circle})

        # Select all arcs
        for arc in self.arcs:
            if not self.is_object_on_locked_layer(arc) and self.is_object_on_visible_layer(arc):
                self.selected_items.append({"type": "arc", "object": arc})

        # Select all roofs
        for roof in getattr(self, 'roofs', []):
            if not self.is_object_on_locked_layer(roof) and self.is_object_on_visible_layer(roof):
                self.selected_items.append({"type": "roof", "object": roof})

        self.queue_draw()
        self.emit('selection-changed', self.selected_items)
        print(f"Selected {len(self.selected_items)} objects")

    def deselect_items_on_layer(self, layer_id):
        """Deselect all items belonging to the specified layer_id."""
        if not layer_id or not self.selected_items:
            return

        new_selection = []
        changed = False

        for item in self.selected_items:
            obj = item["object"]

            # Extract real object to check layer_id
            real_obj = obj
            otype = item.get("type")

            if otype in ("door", "window"):
                if isinstance(obj, tuple) and len(obj) >= 2:
                    real_obj = obj[1]
            elif otype == "vertex":
                if isinstance(obj, tuple) and len(obj) >= 1:
                    real_obj = obj[0]  # The room
            elif otype in ("wall_handle", "polyline_handle", "dimension_handle"):
                if isinstance(obj, tuple) and len(obj) >= 1:
                    real_obj = obj[0]

            # Check layer
            obj_layer = getattr(real_obj, 'layer_id', '')
            if obj_layer == layer_id:
                changed = True
            else:
                new_selection.append(item)

        if changed:
            self.selected_items = new_selection
            self.queue_draw()
            self.emit('selection-changed', self.selected_items)

    def copy_selected(self):
        """Copy selected items to clipboard"""
        import copy as copy_module
        self.clipboard.clear()

        for item in self.selected_items:
            # Store a deep copy of the item dictionary
            self.clipboard.append(copy_module.deepcopy(item))

    def cut_selected(self):
        """Cut selected items (copy + delete)"""
        self.copy_selected()
        self.delete_selected()
        self.save_state()

    def paste(self):
        """Paste clipboard items with offset"""
        if not self.clipboard:
            return

        import copy as copy_module
        import string
        import random

        # Offset for pasted items (12 inches down and right)
        offset = (12, 12)

        # Clear current selection
        self.selected_items.clear()

        # Paste each item
        for item in self.clipboard:
            item_type = item.get("type")

            if item_type == "wall":
                wall = item["object"]
                # Create new wall with offset
                new_wall = self.Wall(
                    start=(
                        wall.start[0] + offset[0],
                        wall.start[1] + offset[1]),
                    end=(
                        wall.end[0] + offset[0],
                        wall.end[1] + offset[1]),
                    width=wall.width,
                    height=wall.height,
                    exterior_wall=wall.exterior_wall,
                    identifier=self.generate_identifier(
                        "wall",
                        self.existing_ids))
                # Copy all other properties
                new_wall.footer = wall.footer
                new_wall.footer_left_offset = wall.footer_left_offset
                new_wall.footer_right_offset = wall.footer_right_offset
                new_wall.footer_depth = wall.footer_depth
                new_wall.material = wall.material
                new_wall.interior_finish = wall.interior_finish
                new_wall.exterior_finish = wall.exterior_finish
                new_wall.stud_spacing = wall.stud_spacing
                new_wall.insulation_type = wall.insulation_type
                new_wall.fire_rating = wall.fire_rating

                # Add to a new wall set
                self.wall_sets.append([new_wall])
                self.selected_items.append(
                    {"type": "wall", "object": new_wall})

            elif item_type == "door":
                # Doors are (wall, door, ratio) tuples
                old_wall, door, ratio = item["object"]
                # Create new door object
                new_door = copy_module.deepcopy(door)
                new_door.identifier = self.generate_identifier(
                    "door", self.existing_ids)

                # Paste on same wall with offset ratio
                new_ratio = ratio + 0.1  # 10% offset along the wall
                if new_ratio > 1.0:
                    # Try going backward or clamp to 0.9
                    new_ratio = min(0.9, ratio - 0.1)

                # Store door on same wall
                new_door_tuple = (old_wall, new_door, new_ratio)
                self.doors.append(new_door_tuple)
                self.selected_items.append(
                    {"type": "door", "object": new_door_tuple})

            elif item_type == "window":
                # Windows are (wall, window, ratio) tuples
                old_wall, window, ratio = item["object"]
                # Create new window object
                new_window = copy_module.deepcopy(window)
                new_window.identifier = self.generate_identifier(
                    "window", self.existing_ids)

                # Paste on same wall with offset ratio
                new_ratio = ratio + 0.1  # 10% offset along the wall
                if new_ratio > 1.0:
                    # Try going backward or clamp to 0.9
                    new_ratio = min(0.9, ratio - 0.1)

                # Store window on same wall
                new_window_tuple = (old_wall, new_window, new_ratio)
                self.windows.append(new_window_tuple)
                self.selected_items.append(
                    {"type": "window", "object": new_window_tuple})

            elif item_type == "text":
                text = item["object"]
                # Create new text with offset
                new_text = copy_module.deepcopy(text)
                new_text.x = text.x + offset[0]
                new_text.y = text.y + offset[1]
                new_text.identifier = self.generate_identifier(
                    "text", self.existing_ids)

                self.texts.append(new_text)
                self.selected_items.append(
                    {"type": "text", "object": new_text})

            elif item_type == "dimension":
                dim = item["object"]
                # Create new dimension with offset
                new_dim = self.Dimension(
                    start=(
                        dim.start[0] + offset[0],
                        dim.start[1] + offset[1]),
                    end=(
                        dim.end[0] + offset[0],
                        dim.end[1] + offset[1]),
                    offset=dim.offset,
                    identifier=self.generate_identifier(
                        "dimension",
                        self.existing_ids),
                    text_size=dim.text_size,
                    show_arrows=dim.show_arrows,
                    line_style=dim.line_style,
                    color=dim.color)

                self.dimensions.append(new_dim)
                self.selected_items.append(
                    {"type": "dimension", "object": new_dim})

            elif item_type == "polyline":
                poly = item["object"]
                # Create new polyline with offset
                new_poly = copy_module.deepcopy(poly)
                new_poly.start = (
                    poly.start[0] + offset[0],
                    poly.start[1] + offset[1])
                new_poly.end = (
                    poly.end[0] + offset[0],
                    poly.end[1] + offset[1])
                new_poly.identifier = self.generate_identifier(
                    "polyline", self.existing_ids)

                # Add as a new polyline set
                self.polyline_sets.append([new_poly])
                self.selected_items.append(
                    {"type": "polyline", "object": new_poly, "identifier": new_poly.identifier})

            elif item_type == "vertex":
                # Room vertices - we'll handle this by pasting the whole room
                # Skip individual vertices
                pass

        # Handle rooms (check for room objects in clipboard)
        rooms_to_paste = set()
        for item in self.clipboard:
            if item["type"] == "vertex":
                room, idx = item["object"]
                # Use object id to track unique rooms
                rooms_to_paste.add(id(room))

        # Paste unique rooms
        for item in self.clipboard:
            if item["type"] == "vertex":
                room, idx = item["object"]
                if id(room) in rooms_to_paste:
                    # Create new room with offset
                    new_points = [(pt[0] + offset[0], pt[1] + offset[1])
                                  for pt in room.points]
                    new_room = self.Room(
                        points=new_points,
                        height=room.height,
                        identifier=self.generate_identifier(
                            "room",
                            self.existing_ids),
                        layer_id=self.active_layer_id)
                    new_room.floor_type = room.floor_type
                    new_room.wall_finish = room.wall_finish
                    new_room.room_type = room.room_type
                    new_room.name = room.name

                    self.rooms.append(new_room)
                    # Add all vertices to selection
                    for i in range(len(new_room.points)):
                        self.selected_items.append(
                            {"type": "vertex", "object": (new_room, i)})

                    rooms_to_paste.remove(id(room))  # Don't paste again

        self.save_state()
        self.queue_draw()
        self.emit('selection-changed', self.selected_items)


def create_canvas_area(config_constants):
    return CanvasArea(config_constants)
